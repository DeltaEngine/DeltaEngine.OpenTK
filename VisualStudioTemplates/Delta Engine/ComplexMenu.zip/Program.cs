using DeltaEngine.Platforms;

namespace $safeprojectname$
{
	internal class Program : App
	{
		public Program()
		{
			new Menu();
		}

		public static void Main()
		{
			new Program().Run();
		}
	}
}
