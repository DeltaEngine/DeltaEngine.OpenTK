namespace $safeprojectname$.Screens
{
	/*TODO
	/// <summary>
	/// The contents of this file are auto generated. Do not edit, Editor will overwrite this.
	/// </summary>
	public partial class Credits : BaseGameScreen
	{
		public Delta.Graphics.UserInterfaces.Controls.Label Label0;
		public Delta.Graphics.UserInterfaces.Controls.Button Button0;
		public Delta.Graphics.UserInterfaces.Controls.Label Label1;
				
		private void InitializeControls()
		{
				this.LoadUIScene("Credits");
				Label0 = this.FindUIControl<Label>("Label0");
				Button0 = this.FindUIControl<Button>("Button0");
				Label1 = this.FindUIControl<Label>("Label1");
		}
	}
	 */
}
