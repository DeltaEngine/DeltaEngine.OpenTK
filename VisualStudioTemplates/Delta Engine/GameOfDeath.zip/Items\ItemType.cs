namespace $safeprojectname$.Items
{
	public enum ItemType
	{
		Mallet,
		Fire,
		Toxic,
		Atomic
	}
}
