namespace $safeprojectname$
{
	public enum RenderLayers
	{
		Background = 0,
		Rabbits = 1,
		Items = 3,
		Gui = 5,
		Icons = 6,
		IntroLogo = 7
	}
}
