namespace $safeprojectname$.Content
{
	public enum BossModels
	{
		CreepBossCloak
	}
}