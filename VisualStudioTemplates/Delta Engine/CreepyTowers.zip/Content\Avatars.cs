namespace $safeprojectname$.Content
{
	public enum Avatars
	{
		Alien,
		Penguin,
		Dragon,
		PiggyBank,
		Panda,
		Teddy,
		Robot,
		Unicorn
	}
}