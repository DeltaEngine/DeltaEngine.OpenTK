namespace $safeprojectname$
{
	public enum CreepyTowersRenderLayer
	{
		Model
	}
}